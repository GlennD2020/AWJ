﻿/*******************************************************************************
 *	@file:		at24c32d.с
 *	@brief:		Исполняемый файл библиотеки для работы с I2C памятью AT24C32.
 *******************************************************************************/
#define __C_I2C_MEM_AT24_

/*******************************************************************************
 *		INCLUDES
 *******************************************************************************/
#include "at24c32d.h"

/*******************************************************************************
 *		FUNCTIONS
 *******************************************************************************/
/**
 *	@brief		AT24_I2C_SetPeriph
 *	@remark		Настройка перифирии для работы с памятью.
 *	@param		hi2c - Указатель на объект для работы с I2C.
 *	@retval		0
 */
int AT24_I2C_SetPeriph		( I2C_HandleTypeDef* hi2c )
{
	mem_periph.hi2c = hi2c;
	return 0;
}

/**
 *	@brief		AT24_I2C_MemoryRead.
 *	@remark		Функция считывания данных из памяти AT24C32D
 *	@param		address - Адрес для считывания данных.
 *	@param		data	- Указатель на массив для сохранения вычитанных данных.
 *	@param		num		- Количество байт для считывания из памяти.
 *	@retval		0
 */
int AT24_I2C_MemoryRead 	( int address, unsigned char* data, uint16_t num )
{
	HAL_StatusTypeDef status = HAL_OK;

	status = HAL_I2C_Mem_Read ( mem_periph.hi2c, (AT24C64_ADDRESS<<1), address, I2C_MEMADD_SIZE_16BIT, data, num, 2000 );

	if ( status == HAL_BUSY )	return -2;
	else if ( status!=HAL_OK )	return -1;
	else return 1;
}

/**
 *	@brief		AT24_I2C_MemoryWrite
 *	@remark		Функция записи данных в память.
 *	@param		address	- Адрес для записи памяти.
 *	@param		data	- Указатель на массив, который необходимо записать.
 *	@param		num		- Количество байт для записи.
 *	@retval		0
 */
int AT24_I2C_MemoryWrite 	( int address, unsigned char* data, uint16_t num )
{
	HAL_StatusTypeDef status = HAL_OK;
	
	status = HAL_I2C_Mem_Write ( mem_periph.hi2c, (AT24C64_ADDRESS<<1), address, I2C_MEMADD_SIZE_16BIT, data, num, 2000 );
	
	if ( status == HAL_BUSY )	return -2;
	else if ( status!=HAL_OK )	return -1;
	else return 1;
}
