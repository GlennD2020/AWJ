/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "dms_functions.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit ( TIM_HandleTypeDef *htim );

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler ( void );

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DDS_SYNC_OUT_Pin 		GPIO_PIN_13
#define DDS_SYNC_OUT_GPIO_Port	GPIOC
#define DIP_SW0_Pin 			GPIO_PIN_0
#define DIP_SW0_GPIO_Port 		GPIOC
#define DIP_SW1_Pin 			GPIO_PIN_1
#define DIP_SW1_GPIO_Port 		GPIOC
#define DIP_SW2_Pin 			GPIO_PIN_2
#define DIP_SW2_GPIO_Port 		GPIOC
#define DIP_SW3_Pin 			GPIO_PIN_3
#define DIP_SW3_GPIO_Port 		GPIOC
#define DIP_SW4_Pin 			GPIO_PIN_0
#define DIP_SW4_GPIO_Port 		GPIOA
#define DIP_SW5_Pin 			GPIO_PIN_1
#define DIP_SW5_GPIO_Port 		GPIOA
#define DIP_SW6_Pin 			GPIO_PIN_2
#define DIP_SW6_GPIO_Port 		GPIOA
#define DIP_SW7_Pin 			GPIO_PIN_3
#define DIP_SW7_GPIO_Port 		GPIOA
#define DAC_ATT_Pin 			GPIO_PIN_4
#define DAC_ATT_GPIO_Port 		GPIOA
#define DET_Pin 				GPIO_PIN_6
#define DET_GPIO_Port 			GPIOA
#define ATT_SW1_Pin				GPIO_PIN_7
#define ATT_SW1_GPIO_Port		GPIOA
#define ATT_SW2_Pin				GPIO_PIN_4
#define ATT_SW2_GPIO_Port		GPIOC
#define ATT_SW3_Pin				GPIO_PIN_0
#define ATT_SW3_GPIO_Port		GPIOB
#define COMP_Pin 				GPIO_PIN_5
#define COMP_GPIO_Port 			GPIOC
#define BUZZER_Pin 				GPIO_PIN_1
#define BUZZER_GPIO_Port 		GPIOB
#define PULSE_CIRCUIT_Pin 		GPIO_PIN_2
#define PULSE_CIRCUIT_GPIO_Port GPIOB
#define PLL_LE_Pin 				GPIO_PIN_12
#define PLL_LE_GPIO_Port 		GPIOB
#define PLL_CLK_Pin 			GPIO_PIN_13
#define PLL_CLK_GPIO_Port 		GPIOB
#define PLL_MUXOUT_Pin 			GPIO_PIN_14
#define PLL_MUXOUT_GPIO_Port	GPIOB
#define PLL_MOSI_Pin 			GPIO_PIN_15
#define PLL_MOSI_GPIO_Port 		GPIOB
#define PLL_LD_Pin 				GPIO_PIN_6
#define PLL_LD_GPIO_Port 		GPIOC
#define ENABLE_Pin 				GPIO_PIN_7
#define ENABLE_GPIO_Port 		GPIOC
#define LED2_Pin 				GPIO_PIN_9
#define LED2_GPIO_Port 			GPIOC
#define LED3_Pin 				GPIO_PIN_8
#define LED3_GPIO_Port 			GPIOA
#define DDS_SCL_Pin 			GPIO_PIN_10
#define DDS_SCL_GPIO_Port 		GPIOC
#define DDS_MSB_OUT_Pin 		GPIO_PIN_11
#define DDS_MSB_OUT_GPIO_Port 	GPIOC
#define DDS_SDATA_Pin 			GPIO_PIN_12
#define DDS_SDATA_GPIO_Port 	GPIOC
#define DDS_FSYNC_Pin 			GPIO_PIN_2
#define DDS_FSYNC_GPIO_Port 	GPIOD
#define DDS_STANDBY_Pin 		GPIO_PIN_5
#define DDS_STANDBY_GPIO_Port 	GPIOB
#define DDS_CTRL_Pin 			GPIO_PIN_8
#define DDS_CTRL_GPIO_Port 		GPIOB
#define DDS_INTERRUPT_Pin 		GPIO_PIN_9
#define DDS_INTERRUPT_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
