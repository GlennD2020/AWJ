/********************************************************************************
 *	@file:		syscom.h
 *	@brief:		Заголовочный файл описывающий систему команд для СЧ 6 ГГц со смесителем.
 *	@version:	v1.0
 *	@author:	Kirillov A.V.
 *	@date:		10/12/2019
 ********************************************************************************/
#ifndef __H_DMS_SYNTHESIZER_SYSCOM_
#define __H_DMS_SYNTHESIZER_SYSCOM_

#define HEAD_OFFSET	6

#pragma pack ( push,1 )
/**
 *	@brief Типовая структура системы команд.
 */
typedef struct 
{
	short Type;				//	0 ... 1
	short Status;			//	2 ... 3
	short Len;				//	4 ... 5
	unsigned char data[26];	//	6 ... 31
}tsSysCmd;
#pragma pack(pop)

#define SYSCOM_SIZE	sizeof(tsSysCmd)

/**
 *	@brief Список команд.
 */
enum
{
    TEST_CONNECT = 1,		//  Тест соединения.
    GET_VERSIONS,			//  Команда вычитывания версия программ.
    GET_STATE,              //  Чтение состояния устройства.
    READ_MEMORY,			//  Чтение памяти.
    WRITE_MEMORY,			//  Запись памяти.
    GET_PLL_REG,			//  Считывание регистра ФАПЧ.
    SET_PLL_REG,			//  Запись регистра ФАПЧ.
    GET_DAC_VALUE,			//  Считывание значения ЦАПа.
    SET_DAC_VALUE,			//  Установка значения ЦАПа.
    GET_SWEEP_PLL,			//  Свип по частоте.
    SET_SWEEP_PLL,			//  Свип по частоте.
    GET_PULSE_CTRL,			//  Управление модулятором.
    SET_PULSE_CTRL,			//  Управление модулятором.
    GET_AMPL_MOD_CTRL,		//  Управление амплитудной модуляции.
    SET_AMPL_MOD_CTRL,		//  Управление амплитудной модуляции.
    GET_CTRL_POWER_DET,		//  Считывание границы.
    SET_CTRL_POWER_DET,		//  Задание границы.
    GET_DIP_FREQ,			//  Считывание частоты переключателя.
    SET_DIP_FREQ,			//  Установка частоты переключателя.
    GET_TIME_INTERVAL,		//  Считвание длительности звуковых сигналов.
    SET_TIME_INTERVAL,		//  Установка длительности звуковых сигналов.
    GET_DDS_REG,			//  Считывание регистра DDS.
    SET_DDS_REG,			//  Запись регистра DDS.
    GET_DDS_CTR_FREQ,		//  Считывание частоты управления DDS.
    SET_DDS_CTR_FREQ,		//  Установка частоты управления DDS.
    GET_SWEEP_DDS,			//	Считывание настроек росчерка DDS.
    SET_SWEEP_DDS,			//	Установка настроек росчерка DDS.
    GET_RAMP_DDS,			//	Считывание настроек аппаратного росчерка DDS.
    SET_RAMP_DDS,			//	Установка настроект аппаратного росчерка DDS.
    RESET_DDS,				//	Сброс микросхемы DDS.
    DEFAULT,				//  Команда перевода устройство в состояние по умолчанию.
};

/**
 *	@brief	Статус выполнения команд.
 */
enum
{
	CMD_NO_ERROR = 0,		//  0 -	Нет ошибки.
	CMD_DONE, 				//  1 - Команда выполнена.
	CMD_UNDEFINED,			//  2 - Команда не определена.
	CMD_DEVICE_ERROR,		//  3 -	Ошибка устройства.
	CMD_RECV_CMD_ERROR,		//  4 -	Ошибка в принятой команде.
	CMD_EEPROM_BUSY,		//  5 -	Микросхема памяти занята.
	CMD_WRITE_EEPROM_ERROR,	//  6 -	Ошибка записи данных в память.
	CMD_READ_EEPROM_ERROR,	//  7 -	Ошибка чтения данных из памяти.
};

#endif	//	__H_DMS_SYNTHESIZER_SYSCOM_
